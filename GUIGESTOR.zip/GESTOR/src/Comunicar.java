
public class Comunicar extends ProcessoM implements MyMessage {
	
	public Comunicar(String nameFile) {
		super(nameFile);
	}
	
	public byte[] msgReta(byte numMsg, int dist) {
		byte[] msg = new byte[msgRETA.length];
		addArrayToArray(msg, msgRETA);
		msg[0] = numMsg;
		msg[2] = (byte) (dist & 0xFF);
		msg[3] = (byte) ((dist >> 8) & 0xFF);
		msg[4] = (byte) ((dist >> 16) & 0xFF);
		msg[5] = (byte) ((dist >> 24) & 0xFF);
		return msg;
		
	}
	
	public byte[] msgParar(byte numMsg, boolean b) {
		byte[] msg = new byte[msgPARAR.length];
		addArrayToArray(msg, msgPARAR);
		msg[0] = numMsg;
		msg[2] = (byte) (b ? 0xFF: 0x0);
		return msg;	
	}
	
	public byte[] msgCurvarE(byte numMsg, int ang, int raio) {
		byte[] msg = new byte[msgCURVARE.length];
		addArrayToArray(msg, msgCURVARE);
		msg[0] = numMsg;
		msg[2] = (byte) (ang & 0xFF);
		msg[3] = (byte) ((ang >> 8) & 0xFF);
		msg[4] = (byte) ((ang >> 16) & 0xFF);
		msg[5] = (byte) ((ang >> 24) & 0xFF);
		msg[6] = (byte) (raio & 0xFF);
		msg[7] = (byte) ((raio >> 8) & 0xFF);
		msg[8] = (byte) ((raio >> 16) & 0xFF);
		msg[9] = (byte) ((raio >> 24) & 0xFF);
		return msg;
	}
	
	public byte[] msgCurvarD(byte numMsg, int ang, int raio) {
		byte[] msg = new byte[msgCURVARD.length];
		addArrayToArray(msg, msgCURVARD);
		msg[0] = numMsg;
		msg[2] = (byte) (ang & 0xFF);
		msg[3] = (byte) ((ang >> 8) & 0xFF);
		msg[4] = (byte) ((ang >> 16) & 0xFF);
		msg[5] = (byte) ((ang >> 24) & 0xFF);
		msg[6] = (byte) (raio & 0xFF);
		msg[7] = (byte) ((raio >> 8) & 0xFF);
		msg[8] = (byte) ((raio >> 16) & 0xFF);
		msg[9] = (byte) ((raio >> 24) & 0xFF);
		return msg;
	}
	
	public byte[] msgOpenNXT(byte numMsg, String nomeRobot) {
		int size = nomeRobot.length();
		byte[] msg = new byte[msgOPENNXT.length - 16 + size];
		addArrayToArray(msg, msgOPENNXT);
		msg[0] = numMsg;
		for (int i = 0; i < nomeRobot.length(); i++)
			msg[2 + i] = (byte) (nomeRobot.charAt(i) & 0xFF);
		return msg;
	}
	
	public byte[] msgCloseNXT(byte numMsg) {
		byte[] msg = new byte[msgCLOSENXT.length];
		addArrayToArray(msg, msgCLOSENXT);
		msg[0] = numMsg;
		return msg;
	}
	
	public byte[] msgOffsetD(byte numMsg, int offset) {
		byte[] msg = new byte[msgOFFSETD.length];
		addArrayToArray(msg, msgOFFSETD);
		msg[0] = numMsg;
		msg[2] = (byte) (offset & 0xFF);
		msg[3] = (byte) ((offset >> 8) & 0xFF);
		msg[4] = (byte) ((offset >> 16) & 0xFF);
		msg[5] = (byte) ((offset >> 24) & 0xFF);
		return msg;
	}
	
	public byte[] msgOffsetE(byte numMsg, int offset) {
		byte[] msg = new byte[msgOFFSETE.length];
		addArrayToArray(msg, msgOFFSETD);
		msg[0] = numMsg;
		msg[2] = (byte) (offset & 0xFF);
		msg[3] = (byte) ((offset >> 8) & 0xFF);
		msg[4] = (byte) ((offset >> 16) & 0xFF);
		msg[5] = (byte) ((offset >> 24) & 0xFF);
		return msg;
	}
	
	public byte[] msgGestor(byte numMsg) {
		byte[] msg = new byte[msgGESTOR.length];
		addArrayToArray(msg, msgGESTOR);
		msg[0] = numMsg;
		return msg;
	}
	
	public byte[] msgEvitar(byte numMsg) {
		byte[] msg = new byte[msgEVITAR.length];
		addArrayToArray(msg, msgEVITAR);
		msg[0] = numMsg;
		return msg;
	}
	
	public byte[] msgVaguear(byte numMsg) {
		byte[] msg = new byte[msgVAGUEAR.length];
		addArrayToArray(msg, msgVAGUEAR);
		msg[0] = numMsg;
		return msg;
	}
	
	public byte[] msgDesativar(byte numMsg) {
		byte[] msg = new byte[msgDESATIVAR.length];
		addArrayToArray(msg, msgDESATIVAR);
		msg[0] = numMsg;
		return msg;
	}	
	
	public byte[] msgACKNOWLEDGE(byte numMsg) {
		byte[] msg = new byte[msgACKNOWLEDGE.length];
		addArrayToArray(msg, msgACKNOWLEDGE);
		msg[0] = numMsg;
		return msg;
	}
	
	public byte[] msgACKNOWLEDGEB(byte numMsg, boolean b) {
		byte[] msg = new byte[msgACKNOWLEDGEB.length];
		addArrayToArray(msg, msgACKNOWLEDGEB);
		msg[0] = numMsg;
		msg[2] = (byte) (b? 0xFF: 0x00);
		return msg;
	}

	private byte[] addArrayToArray(byte[] a, byte[] b) {
		for (int i = 0; i < a.length; i++) {
			a[i] = b[i];
		}
		return a;
	}
	
	
	public String toString(byte[] msg) {
		return "";
	}

	public void clearBuffer(){
		byte[] clear = new byte[BUFFER_MAX];
		enviarMensagem(clear);
	}
}
