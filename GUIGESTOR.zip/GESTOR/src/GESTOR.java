import java.util.Arrays;

public class GESTOR {

	RobotChannel gestor_gui, rcVaguear, rcEvitar;
	Comunicar receive, send;

	static String channelName;
	int lastN;
	byte[] msg;
	boolean b;

	MyRobotLego robot;
	String nomeRobot = "Link";

	byte state;
	final byte sleepInactive = 0x0E, sleepActive = 0x0F, sleepOn = 0x10, AcknowledgeOn = 0x11,
			readMessageInactive = 0x12, readMessageActive = 0x13, readMessageOn = 0x14;

	public GESTOR() {
		
		gestor_gui = new RobotChannel("GESTOR - GUI");
//		rcVaguear = new RobotChannel("GESTOR - VAGUEAR");
//		rcEvitar = new RobotChannel("GESTOR - EVITAR");
		receive = gestor_gui.channel2;
		send = gestor_gui.channel1;
		
		receive.clearBuffer();
		send.clearBuffer();

		robot = new MyRobotLego();

		lastN = 0;
		msg = new byte[receive.BUFFER_MAX];
		b = false;

		state = sleepInactive;
	}

	public void run() {
//		rcGui.NonActiveSwitch();
//		rcVaguear.NonActiveSwitch();
//		rcEvitar.
		NonActiveSwitch();
	}

	public static void main(String[] args) {
		GESTOR gt = new GESTOR();
		while(true) {
			gt.run();
		}
		
	}

	public void NonActiveSwitch() {
		switch (state) {
		case sleepInactive:
//			System.out.println("oi msg = " + Arrays.toString(msg));
//			myPrint(Arrays.toString(msg), receive);
			try {
				Thread.sleep(2500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			state = readMessageInactive;
			break;

		case sleepActive:
			try {
				Thread.sleep(2500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			state = readMessageActive;
			break;

		case sleepOn:
			try {
				Thread.sleep(2500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			state = readMessageOn;
			break;

		case readMessageInactive:
			msg = receive.receberMensagemByte();
			gestor_gui.myPrint(msg, gestor_gui.receive);
			if (msg[0] == lastN)
				state = sleepInactive;
			else
				state = MyMessage.IDACKNOWLEDGE;
			break;

		case readMessageActive:
			msg = receive.receberMensagemByte();
			gestor_gui.myPrint(msg, gestor_gui.receive);
			if (msg[0] == lastN)
				state = sleepActive;
			else
				state = MyMessage.IDACKNOWLEDGEB;
			break;

		case readMessageOn:
			msg = receive.receberMensagemByte();
			gestor_gui.myPrint(msg, gestor_gui.receive);
			if (msg[0] == lastN)
				state = sleepOn;
			else
				state = AcknowledgeOn;
			break;

		case MyMessage.IDACKNOWLEDGE:
			receive.clearBuffer();
			gestor_gui.incrementNumMsg();
			send.enviarMensagem(send.msgACKNOWLEDGE(gestor_gui.numMsg));
			gestor_gui.myPrint(send.msgACKNOWLEDGE(gestor_gui.numMsg), gestor_gui.send);
			lastN = msg[0];
			if (msg[1] != MyMessage.IDGESTOR)
				state = sleepInactive;
			else
				state = sleepActive;
			break;

		case MyMessage.IDACKNOWLEDGEB:
			lastN = msg[0];
			if (msg[1] == MyMessage.IDOPEN)
				b = robot.OpenNXT(nomeRobot);
			else if (msg[1] == MyMessage.IDDESATIVAR) {
				state = sleepInactive;
				break;
			} else {
				state = sleepActive;
				break;
			}
			receive.clearBuffer();
			gestor_gui.incrementNumMsg();
			send.enviarMensagem(send.msgACKNOWLEDGEB(gestor_gui.numMsg, b));
			gestor_gui.myPrint(send.msgACKNOWLEDGEB(gestor_gui.numMsg, b), gestor_gui.send);
			if (b)
				state = sleepOn;
			else
				state = sleepActive;
			break;

		case AcknowledgeOn:
			receive.clearBuffer();
			gestor_gui.incrementNumMsg();
			send.enviarMensagem(send.msgACKNOWLEDGE(gestor_gui.numMsg));
			gestor_gui.myPrint(send.msgACKNOWLEDGE(gestor_gui.numMsg), gestor_gui.send);
			lastN = msg[0];
			if (msg[1] == MyMessage.IDDESATIVAR)
				state = sleepInactive;
			else {
				ActiveSwitch(msg);
				state = sleepOn;
			}
			break;

		default:
			System.out.println("ERROR: nonActiveSwitch");
			break;
		}

	}

	private void ActiveSwitch(byte[] m) {
		switch (m[1]) {
		case MyMessage.IDCURVAD:
			robot.CurvarDireita(byteToInt(m, 2, 5), byteToInt(m, 6, 9));
			break;
		case MyMessage.IDCURVAE:
			robot.CurvarEsquerda(byteToInt(m, 2, 5), byteToInt(m, 6, 9));
			break;
		case MyMessage.IDOSD:
			robot.OffsetDireito(byteToInt(m, 2, 5));
			break;
		case MyMessage.IDOSE:
			robot.OffsetEsquerdo(byteToInt(m, 2, 5));
			break;
		case MyMessage.IDPARAR:
			robot.Parar(byteToBoolean(m, 2));
			break;
		case MyMessage.IDRETA:
			robot.Reta(byteToInt(m, 2, 5));
			break;
		default:
			System.out.println("ID n�o esperado.");
			break;
		}
	}

	private int byteToInt(byte[] a, int i, int f) {
		int num = 0;
		for (int n = i; n <= f; n++)
			num += a[n] * Math.pow(2, n - i);
		return num;
	}

	private boolean byteToBoolean(byte[] a, int i) {
		return ((a[i] & 0x0F) == 0x0F);
	}

}
