import java.util.Arrays;

public class GESTOR {

	RobotChannel rcGui, rcVaguear, rcEvitar;

	static String channelName;
	int lastN;
	byte[] msg;
	boolean b;

	MyRobotLego robot;
	String nomeRobot = "Link";
	byte numMsg;

	byte state;
	final byte sleepInactive = 0x0E, sleepActive = 0x0F, sleepOn = 0x10, AcknowledgeOn = 0x11,
			readMessageInactive = 0x12, readMessageActive = 0x13, readMessageOn = 0x14;

	public GESTOR() {

		rcGui = new RobotChannel("GESTOR - GUI");
//		rcVaguear = new RobotChannel("GESTOR - VAGUEAR");
//		rcEvitar = new RobotChannel("GESTOR - EVITAR");

		robot = new MyRobotLego();

		lastN = -1;
		msg = new byte[rcGui.receiveCom.channel.BUFFER_MAX];
		b = false;

		numMsg = 0;

		state = sleepInactive;
	}

	public void run() {
//		rcGui.NonActiveSwitch();
//		rcVaguear.NonActiveSwitch();
//		rcEvitar.
		NonActiveSwitch();
	}

	public static void main(String[] args) {
		GESTOR gt = new GESTOR();
		gt.run();
	}

	public void NonActiveSwitch() {
		switch (state) {

		case sleepInactive:
//			System.out.println("oi msg = " + Arrays.toString(msg));
//			myPrint(Arrays.toString(msg), receive);
			try {
				Thread.sleep(0);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			state = readMessageInactive;
			break;

		case sleepActive:
			try {
				Thread.sleep(0);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			state = readMessageActive;
			break;

		case sleepOn:
			try {
				Thread.sleep(0);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			state = readMessageOn;
			break;

		case readMessageInactive:
			System.out.println("tao?");
			msg = rcGui.receiveCom.channel.receberMensagemByte();
			rcGui.myPrint(msg, rcGui.receive);
			System.out.println("oi" + Arrays.toString(msg));
			if (msg[0] == lastN)
				state = sleepInactive;
			else
				state = MyMessage.IDACKNOWLEDGE;
			break;

		case readMessageActive:
			msg = rcGui.receiveCom.channel.receberMensagemByte();
			rcGui.myPrint(msg, rcGui.receive);
			if (msg[0] == lastN)
				state = sleepActive;
			else
				state = MyMessage.IDACKNOWLEDGEB;
			break;

		case readMessageOn:
			msg = rcGui.receiveCom.channel.receberMensagemByte();
			rcGui.myPrint(msg, rcGui.receive);
			if (msg[0] == lastN)
				state = sleepOn;
			else
				state = AcknowledgeOn;
			break;

		case MyMessage.IDACKNOWLEDGE:
			rcGui.sendCom.channel.enviarMensagem(rcGui.sendCom.msgACKNOWLEDGE(numMsg));
			rcGui.myPrint(rcGui.sendCom.msgACKNOWLEDGE(numMsg), rcGui.send);
			numMsg++;
			lastN = msg[0];
			if (msg[1] != MyMessage.IDGESTOR)
				state = sleepInactive;
			else
				state = sleepActive;
			break;

		case MyMessage.IDACKNOWLEDGEB:
			numMsg++;
			lastN = msg[0];
			if (msg[1] == MyMessage.IDOPEN)
				b = robot.OpenNXT(nomeRobot);
			else if (msg[1] == MyMessage.IDDESATIVAR) {
				state = sleepInactive;
				break;
			} else {
				state = sleepActive;
				break;
			}
			rcGui.sendCom.channel.enviarMensagem(rcGui.sendCom.msgACKNOWLEDGEB(numMsg, b));
			rcGui.myPrint(rcGui.sendCom.msgACKNOWLEDGEB(numMsg, b), rcGui.send);
			if (b)
				state = sleepOn;
			else
				state = sleepActive;
			break;

		case AcknowledgeOn:
			rcGui.sendCom.channel.enviarMensagem(rcGui.sendCom.msgACKNOWLEDGE(numMsg));
			rcGui.myPrint(rcGui.sendCom.msgACKNOWLEDGE(numMsg), rcGui.send);
			numMsg++;
			lastN = msg[0];
			if (msg[1] == MyMessage.IDDESATIVAR)
				state = sleepInactive;
			else {
				ActiveSwitch(msg);
				state = sleepOn;
			}
			break;

		default:
			System.out.println("ERROR: nonActiveSwitch");
			break;
		}

	}

	private void ActiveSwitch(byte[] m) {
		switch (m[1]) {
		case MyMessage.IDCURVAD:
			robot.CurvarDireita(byteToInt(m, 2, 5), byteToInt(m, 6, 9));
			break;
		case MyMessage.IDCURVAE:
			robot.CurvarEsquerda(byteToInt(m, 2, 5), byteToInt(m, 6, 9));
			break;
		case MyMessage.IDOSD:
			robot.OffsetDireito(byteToInt(m, 2, 5));
			break;
		case MyMessage.IDOSE:
			robot.OffsetEsquerdo(byteToInt(m, 2, 5));
			break;
		case MyMessage.IDPARAR:
			robot.Parar(byteToBoolean(m, 2));
			break;
		case MyMessage.IDRETA:
			robot.Reta(byteToInt(m, 2, 5));
			break;
		default:
			System.out.println("ID n�o esperado.");
			break;
		}
	}

	private int byteToInt(byte[] a, int i, int f) {
		int num = 0;
		for (int n = i; n <= f; n++)
			num += a[n] * Math.pow(2, n - i);
		return num;
	}

	private boolean byteToBoolean(byte[] a, int i) {
		return ((a[i] & 0x0F) == 0x0F);
	}

}
