import java.awt.EventQueue;
import java.util.Arrays;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;

public class RobotChannel extends JFrame {
	
	static RobotChannel rc;

	private JPanel contentPane;	
	JTextArea send, receive;
	JLabel LabelEnviar, LabelReceber;
	private JTextArea channelArea;
	private JLabel labelCanal;
	
	private String newline = "\n";
	
	Comunicar receiveCom, sendCom;
	
	String channelName;
	int lastN;
	byte[] msg;
	boolean b;

	MyRobotLego robot;
	String nomeRobot = "Link";
	byte numMsg;

	byte state;
	final byte sleepInactive = 0x0E, sleepActive = 0x0F, sleepOn = 0x10, AcknowledgeOn = 0x11,
			readMessageInactive = 0x12, readMessageActive = 0x13, readMessageOn = 0x14;
	

	public RobotChannel(String channelName) {
		initialize();
		
		receiveCom = new Comunicar("receive");
		sendCom = new Comunicar("send"); 
		
		this.channelName = channelName;
		myPrint(this.channelName, channelArea);
		
	}
	
	public void run() {
		rc = new RobotChannel(this.channelName);
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		rc.run();
	}



	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 418);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		LabelReceber = new JLabel("Receber");
		LabelReceber.setBounds(50, 34, 62, 14);
		contentPane.add(LabelReceber);
		
		LabelEnviar = new JLabel("Enviar");
		LabelEnviar.setBounds(50, 198, 62, 14);
		contentPane.add(LabelEnviar);
		
		receive = new JTextArea();
		receive.setBounds(29, 59, 365, 128);
		contentPane.add(receive);
		
		send = new JTextArea();
		send.setBounds(29, 223, 365, 145);
		contentPane.add(send);
		
		labelCanal = new JLabel("Canal");
		labelCanal.setBounds(128, 16, 46, 14);
		contentPane.add(labelCanal);
		
		channelArea = new JTextArea();
		channelArea.setBounds(167, 11, 157, 22);
		contentPane.add(channelArea);
		
		setVisible(true);
	}

	public void myPrint(String str, JTextArea a){
		a.append(str + newline);
	}
	
	public void myPrint(byte[] msg2, JTextArea a){
		a.append(Arrays.toString(msg2) + newline);
	}
}
