import java.awt.EventQueue;
import java.util.Arrays;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import java.awt.BorderLayout;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;

public class RobotChannel extends JFrame {

	private JPanel contentPane;	
	private JTextArea channelArea;
	private JLabel labelCanal;
	private JLabel LabelEnviar, LabelReceber;
	private JScrollPane scrollPane, scrollPane1;
	JTextArea send, receive;
	
	private String newline = "\n";
	
	Comunicar channel1, channel2;
	
	static String channelName;
	
	byte numMsg;

	public RobotChannel(String channelName) {
		initialize();
		
		channel1 = new Comunicar("channel1");
		channel2 = new Comunicar("channel2"); 
		
		RobotChannel.channelName = channelName;
		myPrint(channelName, channelArea);
		
		numMsg = 0;
	}
	
	public void run() {
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		RobotChannel rc = new RobotChannel(channelName);
		rc.run();
	}
	
	public void incrementNumMsg() {
		numMsg++;
	}


	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 418);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		LabelReceber = new JLabel("Receber");
		LabelReceber.setBounds(50, 34, 62, 14);
		contentPane.add(LabelReceber);
		
		LabelEnviar = new JLabel("Enviar");
		LabelEnviar.setBounds(50, 198, 62, 14);
		contentPane.add(LabelEnviar);
		
		//
		scrollPane = new JScrollPane();
		scrollPane.setBounds(29, 59, 365, 128);
		contentPane.add(scrollPane);
		
		receive = new JTextArea();
		scrollPane.setViewportView(receive);
		receive.setLineWrap(true);
		receive.setEditable(false);
		
		scrollPane1 = new JScrollPane();
		scrollPane1.setBounds(29, 223, 365, 145);
		contentPane.add(scrollPane1);
		
		send = new JTextArea();
		scrollPane1.setViewportView(send);
		send.setLineWrap(true);
		send.setEditable(false);
		//
		
		labelCanal = new JLabel("Canal");
		labelCanal.setBounds(128, 16, 46, 14);
		contentPane.add(labelCanal);
		
		channelArea = new JTextArea();
		channelArea.setBounds(167, 11, 157, 22);
		contentPane.add(channelArea);
		channelArea.setLineWrap(true);
		channelArea.setEditable(false);
		
		setVisible(true);
	}

	public void myPrint(String str, JTextArea a){
		a.append(str + newline);
	}
	
	public void myPrint(byte[] msg2, JTextArea a){
		a.append(Arrays.toString(msg2) + newline);
	}
}
