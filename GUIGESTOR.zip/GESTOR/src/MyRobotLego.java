
public class MyRobotLego {
//	Auxiliar aux = new Auxiliar();
	public boolean OpenNXT(String s) {
		System.out.println("OpenNXT ligado" + s);
//		Thread.sleep(100);
		return true;
	}
	public void CloseNXT(){
		System.out.println("CloseNXT");
	}
	public void CurvarDireita(int r, int a){
		System.out.println("Curva � Direita: raio " + r + " angulo " + a);
	}
	public void CurvarEsquerda(int r, int a){
		System.out.println("Curva � Esquerda: raio " + r + " angulo " + a);
	}
	public void Parar(boolean b){
		System.out.println("Parar: " + b);
	}
	public void Reta(int d){
		System.out.println("Reta: " + d);
	}
	public void OffsetEsquerdo(int offset){
		System.out.println("Offset Esquerdo: " + offset);
	}
	public void OffsetDireito(int offset){
		System.out.println("Offset Direito: " + offset);
	}
	
//	public boolean Sensor(int input){
//		return aux.getSensor();
//	}
	public void setSensorTouch(int input){
		System.out.println("Sensor Activado.");
	}
}
