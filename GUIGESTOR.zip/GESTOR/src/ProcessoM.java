import java.io.*;
import java.nio.Buffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.util.Arrays;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class ProcessoM {

	// ficheiro
	File ficheiro;

	// canal que liga o conte�do do ficheiro ao Buffer
	FileChannel canal;

	// buffer
	MappedByteBuffer buffer;

	// dimens�o m�xima em bytes do buffer
	final int BUFFER_MAX = MyMessage.msgOPENNXT.length * 2;

	// construtor onde se cria o canal
	ProcessoM(String nameFile) {
		ficheiro = new File("C:\\Users\\erica\\Desktop\\" + nameFile + ".dat");
		// cria um canal de comunica��o de leitura e escrita
		try {
			canal = new RandomAccessFile(ficheiro, "rw").getChannel();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		// mapeia para mem�ria o conte�do do ficheiro
		try {
			buffer = canal.map(FileChannel.MapMode.READ_WRITE, 0, BUFFER_MAX);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// recebe uma mensagem convertendo-a numa String
	String receberMensagem() {
		String msg = new String();
		char c;
		buffer.position(0);
		while ((c = buffer.getChar()) != '\0')
			msg += c;
		return msg;
	}

	// envia uma String como mensagem
	void enviarMensagem(String msg) {
		char c;
		buffer.position(0);
		for (int i = 0; i < msg.length(); ++i) {
			c = msg.charAt(i);
			buffer.putChar(c);
		}
		buffer.putChar('\0');
	}

	// recebe uma mensagem convertendo-a num byte[]
	byte[] receberMensagemByte() {
		byte[] msg = new byte[BUFFER_MAX];
		buffer.position(0);
		for (int i = 0; i < msg.length; i++) {
			msg[i] = buffer.get();
		}
		System.out.println("teste receber: " + Arrays.toString(msg));
		return msg;
	}
	// envia um byte[] como mensagem
	public void enviarMensagem(byte[] msg) {
//		byte[] m = new byte[] {0x0A, 0x0B, 0x06, 0x01};
		byte[] m = msg;
		buffer.position(0);
		for (int i = 0; i < m.length; i++) {
			buffer.put(m[i]);
		}
//		System.out.println("0: " + buffer.get(0) + ", 1: " + buffer.get(1) + ", 2: " + buffer.get(2) + ", 3: " + buffer.get(3));
	}

	// fecha o canal entre o buffer e o ficheiro
	void fecharCanal() {
		try {
			canal.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
