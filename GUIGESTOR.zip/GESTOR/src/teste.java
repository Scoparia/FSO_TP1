
public class teste {
	
	private static int state = 0;
	
	static byte b = 0;

	public static void main(String[] args) {
		System.out.println("b: " + b);
		b++;
		System.out.println("b++: " + b);
		b++;
		System.out.println("b++: " + b);
	}
	
	public static void switchoi() {
		switch(state){
		case 0:
			System.out.println("0: " + state);
			state = 2;
			break;
		case 1:
			System.out.println("1: " + state);
			state = 3;
			break;
		case 2:
			System.out.println("2: " + state);
			state = 1;
			break;
		case 3:
			System.out.println("3: " + state);
			state = 0;
			break;
		}
	}

}
