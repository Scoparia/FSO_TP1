
public interface MyMessage {

	final byte IDRETA = 0x00;
	final byte IDPARAR = 0x01;
	final byte IDCURVAE = 0x02;
	final byte IDCURVAD = 0x03;
	final byte IDOPEN = 0x04;
	final byte IDCLOSE = 0x05;
	final byte IDOSD = 0x06;
	final byte IDOSE = 0x07;
	final byte IDGESTOR = 0x08;
	final byte IDEVITAR = 0x09;
	final byte IDVAGUEAR = 0x0A;
	final byte IDDESATIVAR = 0x0B;
	final byte IDACKNOWLEDGE = 0x0C;
	final byte IDACKNOWLEDGEB = 0x0D;
	
	final byte[] msgRETA = {0, IDRETA, 0, 0, 0, 0};
	final byte[] msgPARAR = {0, IDPARAR, 0};
	final byte[] msgCURVARE = {0, IDCURVAE, 0, 0, 0, 0, 0, 0, 0, 0};
	final byte[] msgCURVARD = {0, IDCURVAD, 0, 0, 0, 0, 0, 0, 0, 0};
	final byte[] msgOPENNXT = {0, IDOPEN, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	final byte[] msgCLOSENXT = {0, IDCLOSE};
	final byte[] msgOFFSETD = {0, IDOSD, 0, 0, 0, 0};
	final byte[] msgOFFSETE = {0, IDOSE, 0, 0, 0, 0};
	final byte[] msgGESTOR = {0, IDGESTOR};
	final byte[] msgEVITAR = {0, IDEVITAR};
	final byte[] msgVAGUEAR = {0, IDVAGUEAR};
	final byte[] msgDESATIVAR = {0, IDDESATIVAR};
	final byte[] msgACKNOWLEDGE = {0, IDACKNOWLEDGE}; 
	final byte[] msgACKNOWLEDGEB = {0, IDACKNOWLEDGEB, 0};
	
}
