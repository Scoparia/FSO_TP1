import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JCheckBox;
import java.awt.Color;

public class GUI extends JFrame {

	private JPanel contentPane;
	private JTextField offset_Esquerdo;
	private JTextField offset_Direito;
	private JTextField nome;
	private JTextField distancia;
	private JTextField angulo;
	private JTextField raio;
	private JCheckBox boxGestor, boxVaguear, boxEvitar, debug;

	private JButton frente, retaguarda, parar, esquerda, direita;
	JRadioButton onOff;

	private JScrollPane scrollPane;
	private JTextArea debugArea;

	private final static String newline = "\n";

	Variaveis nv;
	RobotChannel gui_gestor;
	Comunicar receive, send;
	// ProcessoM receive, send;

	public void run() {
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		GUI frame = new GUI();
		frame.run();
	}

	/**
	 * Create the application.
	 */
	public GUI() {
		nv = new Variaveis();
		gui_gestor = new RobotChannel("GUI - GESTOR");
		receive = gui_gestor.receiveCom;
		send = gui_gestor.sendCom;

		initialize();
		disableButtons(false);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		setBounds(100, 100, 450, 462);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		offset_Esquerdo = new JTextField("" + nv.getOffsetEsquerdo());
		offset_Esquerdo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				nv.setOffsetEsquerdo(Integer.parseInt(offset_Esquerdo.getText()));
				myPrint("Offset Esquerdo: " + nv.getOffsetEsquerdo());
			}
		});
		offset_Esquerdo.setBounds(10, 30, 45, 20);
		contentPane.add(offset_Esquerdo);
		offset_Esquerdo.setColumns(10);

		JLabel labelOffsetEsquerdo = new JLabel("Offset Motor Esquerdo");
		labelOffsetEsquerdo.setBounds(10, 11, 122, 14);
		contentPane.add(labelOffsetEsquerdo);

		JLabel labelOffsetDireito = new JLabel("Offset Motor Direito");
		labelOffsetDireito.setBounds(315, 11, 109, 14);
		contentPane.add(labelOffsetDireito);

		offset_Direito = new JTextField("" + nv.getOffsetDireito());
		offset_Direito.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				nv.setOffsetDireito(Integer.parseInt(offset_Direito.getText()));
				myPrint("Offset Direito: " + nv.getOffsetDireito());
			}
		});
		offset_Direito.setBounds(379, 30, 45, 20);
		contentPane.add(offset_Direito);
		offset_Direito.setColumns(10);

		JLabel labelNome = new JLabel("Nome");
		labelNome.setBounds(10, 61, 46, 14);
		contentPane.add(labelNome);

		nome = new JTextField(nv.getNome());
		nome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				nv.setNome(nome.getText());
				myPrint("Nome do Robot: " + nv.getNome());
				gui_gestor.nomeRobot = nome.toString();
			}

		});
		nome.setBounds(41, 58, 215, 20);
		contentPane.add(nome);
		nome.setColumns(10);

		onOff = new JRadioButton("On/Off");
		onOff.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (nv.getOnOff())
					send.msgOpenNXT(gui_gestor.numMsg, gui_gestor.nomeRobot);
				disableButtons(!nv.getOnOff());
			}
		});
		onOff.setBounds(273, 57, 109, 23);
		contentPane.add(onOff);

		/*
		 * if(nv.robot().OpenNXT(nv.getNome())){
		 * nv.setOnOff(nv.robot().OpenNXT(nv.getNome()));
		 * myPrint("Liga��o do modelo Servidor-Cliente bem sucedida."); }else{
		 * myPrint("Insucesso na liga��o."); } }else{ myPrint("OnOff foi desligado.");
		 * nv.robot().CloseNXT(); nv.setOnOff(false); }
		 */

		JLabel labelDistancia = new JLabel("Dist\u00E2ncia");
		labelDistancia.setBounds(9, 95, 46, 14);
		contentPane.add(labelDistancia);

		JLabel labelAngulo = new JLabel("\u00C2ngulo");
		labelAngulo.setBounds(86, 95, 46, 14);
		contentPane.add(labelAngulo);

		JLabel labelRaio = new JLabel("Raio");
		labelRaio.setBounds(163, 95, 46, 14);
		contentPane.add(labelRaio);

		distancia = new JTextField("" + nv.getDistancia());
		distancia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				nv.setDistancia(Integer.parseInt(distancia.getText()));

				myPrint("Distancia: " + nv.getDistancia());

			}
		});
		distancia.setBounds(10, 111, 45, 20);
		contentPane.add(distancia);
		distancia.setColumns(10);

		angulo = new JTextField("" + nv.getAngulo());
		angulo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				nv.setAngulo(Integer.parseInt(angulo.getText()));

				myPrint("Angulo: " + nv.getAngulo());

			}
		});
		angulo.setBounds(86, 111, 45, 20);
		contentPane.add(angulo);
		angulo.setColumns(10);

		raio = new JTextField("" + nv.getRaio());
		raio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				nv.setRaio(Integer.parseInt(raio.getText()));

				myPrint("Raio: " + nv.getRaio());

			}
		});
		raio.setBounds(163, 111, 45, 20);
		contentPane.add(raio);
		raio.setColumns(10);

		frente = new JButton("Frente");
		frente.setForeground(Color.BLACK);
		frente.setBackground(Color.GREEN);
		frente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				myPrint("Frente " + nv.getDistancia());

				send.msgReta(gui_gestor.numMsg, nv.getDistancia());
				// myRobot.Reta(nv.getDistancia());
				send.msgParar(gui_gestor.numMsg, false);
				// myRobot.Parar(false);
			}
		});
		frente.setBounds(150, 146, 130, 37);
		contentPane.add(frente);

		parar = new JButton("Parar");
		parar.setForeground(Color.BLACK);
		parar.setBackground(Color.RED);
		parar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				myPrint("Parar");

				send.msgParar(gui_gestor.numMsg, true);

			}
		});
		parar.setBounds(150, 194, 130, 37);
		contentPane.add(parar);

		retaguarda = new JButton("Retaguarda");
		retaguarda.setForeground(Color.BLACK);
		retaguarda.setBackground(Color.YELLOW);
		retaguarda.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				myPrint("Retaguarda " + nv.getDistancia());

				send.msgReta(gui_gestor.numMsg, -nv.getDistancia());

				send.msgParar(gui_gestor.numMsg, false);

			}
		});
		retaguarda.setBounds(150, 242, 130, 37);
		contentPane.add(retaguarda);

		esquerda = new JButton("Esquerda");
		esquerda.setForeground(Color.BLACK);
		esquerda.setBackground(Color.BLUE);
		esquerda.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				myPrint("Esquerda " + nv.getRaio() + " " + nv.getAngulo());

				send.msgCurvarE(gui_gestor.numMsg, nv.getAngulo(), nv.getRaio());

			}
		});
		esquerda.setBounds(10, 194, 130, 37);
		contentPane.add(esquerda);

		direita = new JButton("Direita");
		direita.setForeground(Color.BLACK);
		direita.setBackground(Color.CYAN);
		direita.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

//				if(nv.getOnOff()){

				myPrint("Direita " + nv.getRaio() + " " + nv.getAngulo());

				send.msgCurvarD(gui_gestor.numMsg, nv.getAngulo(), nv.getRaio());
//				}
			}
		});
		direita.setBounds(290, 194, 121, 37);
		contentPane.add(direita);

		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 320, 414, 95);
		contentPane.add(scrollPane);

		boxGestor = new JCheckBox("Gestor");
		boxGestor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (boxGestor.isSelected()) {
					send.channel.enviarMensagem(send.msgGestor(gui_gestor.numMsg));
					gui_gestor.myPrint(send.msgGestor(gui_gestor.numMsg), gui_gestor.send);
				}
			}
		});
		boxGestor.setBounds(315, 242, 97, 23);
		contentPane.add(boxGestor);

		boxVaguear = new JCheckBox("Vaguear");
		boxVaguear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (boxVaguear.isSelected()) {
					send.channel.enviarMensagem(send.msgVaguear(gui_gestor.numMsg));
					gui_gestor.myPrint(send.msgVaguear(gui_gestor.numMsg), gui_gestor.send);
				}
			}
		});
		boxVaguear.setBounds(316, 263, 97, 23);
		contentPane.add(boxVaguear);

		boxEvitar = new JCheckBox("Evitar");
		boxEvitar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (boxEvitar.isSelected()){
					send.channel.enviarMensagem(send.msgEvitar(gui_gestor.numMsg));
					gui_gestor.myPrint(send.msgVaguear(gui_gestor.numMsg), gui_gestor.send);
				}
			}
		});
		boxEvitar.setBounds(316, 284, 97, 23);
		contentPane.add(boxEvitar);

		debug = new JCheckBox("Debug");
		debug.setBounds(10, 290, 97, 23);
		contentPane.add(debug);

		debugArea = new JTextArea();
		debugArea.setBounds(10, 320, 412, 93);
		contentPane.add(debugArea);
		debugArea.setLineWrap(true);
		// logging.setBounds(10, 333, 414, 95);
		// contentPane.add(logging);
		debugArea.setEditable(false);

		setVisible(true);
	}

	public void myPrint(String s) {
		if (nv.getDebug())
			debugArea.append(s + newline);
	}

	public void disableButtons(boolean b) {
		frente.setEnabled(b);
		retaguarda.setEnabled(b);
		parar.setEnabled(b);
		direita.setEnabled(b);
		esquerda.setEnabled(b);
	}
}
